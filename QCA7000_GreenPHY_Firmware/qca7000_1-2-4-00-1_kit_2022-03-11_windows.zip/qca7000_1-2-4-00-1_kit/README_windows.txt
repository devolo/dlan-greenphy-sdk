
Use windows\qca7000-update.cmd to update and/or configure your 
devolo dLAN Green PHY Module. 

The tools used by the script require a packet driver to send
and receive Layer2 Ethernet frames. You already have this driver
if you have installed devolo Cockpit:
-> https://www.devolo.de/support/downloads/download/devolo-cockpit

As an alternative, you can also install the WinPCAP driver:
-> https://www.winpcap.org/install/bin/WinPcap_4_1_3.exe

Calling the script without arguments gives you a short command 
line help:

 Usage:
 qca7000-update <config-profile> [mac-address]

  config-profile must be one of:

   iot-generic    IoT generic, optimized for performance: 50561 off (SLAC off)
   iot-conform    IoT over mains, optimized for conformity: 50561 on (SLAC off)
   emob-charger   e-mobility use as charging station: SLAC in EVSE mode�(50561 off)
   emob-vehicle   e-mobility use as vehicle: SLAC in PEV mode (50561 off)

  mac-address is optional, if omitted, the first
  localy attached adapter will be programmed


